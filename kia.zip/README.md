# Kia Pet Kuaför & Spa - Randevu Sunucusu

Bu sunucu, sitedeki "Email ile Randevu Al" formundan gelen talepleri alır,
barsel1107@gmail.com adresine bildirim gönderir; oradaki **Onayla / Reddet**
linklerine tıklanınca da müşteriye otomatik bilgilendirme e-postası atar.

## Kurulum

```
cd kia-appointment-server
npm install
```

## Gmail App Password ayarlama (ZORUNLU)

Gmail, normal şifrenizle üçüncü parti uygulamalardan mail atmaya izin vermez.
"Uygulama Şifresi" (App Password) oluşturmanız gerekiyor:

1. barsel1107@gmail.com hesabına giriş yapın.
2. Google Hesabı > Güvenlik > "2 Adımlı Doğrulama"yı açın (kapalıysa önce bunu açmalısınız).
3. https://myaccount.google.com/apppasswords adresine gidin.
4. Yeni bir uygulama şifresi oluşturun (isim olarak "Kia Pet Randevu" yazabilirsiniz).
5. Google'ın verdiği 16 haneli kodu kopyalayıp `config.js` içindeki
   `EMAIL_APP_PASSWORD` alanına yapıştırın.

## Çalıştırma

```
npm start
```

Sunucu varsayılan olarak `http://localhost:3001` adresinde çalışır.
Site (`index.html`) bu adrese `http://localhost:3001` olarak fetch atıyor
(`script.js` içindeki `API_BASE` değişkeni) — bilgisayarınızda test ederken
hem siteyi hem bu sunucuyu aynı anda açık tutmanız yeterli.

## Canlıya alma (deploy)

Bu bir Node.js sunucusu olduğu için GitHub Pages gibi statik hosting'lerde
çalışmaz — bir VPS'e veya Node destekleyen bir hosting'e (Railway, Render,
Fly.io vb.) taşımanız gerekir. Taşıdıktan sonra:

1. `config.js` içindeki `BASE_URL` değerini gerçek sunucu adresinizle
   değiştirin (örn. `https://api.kiapetkuafor.com`), yoksa onay/red
   e-postalarındaki linkler `localhost`'a işaret eder.
2. Site tarafında `script.js` içindeki `API_BASE` değişkenini de aynı
   adresle güncelleyin.

## Veri saklama

Randevular basit bir `appointments.json` dosyasında tutulur (veritabanı yok).
Bu dosyayı silmeyin, geçmiş randevu kayıtlarını kaybedersiniz.
