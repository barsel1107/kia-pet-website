// ─────────────────────────────────────────────────────────────
// Kia Pet Kuaför & Spa - Randevu Sunucusu Ayarları
// ─────────────────────────────────────────────────────────────
// EMAIL_APP_PASSWORD: Google Hesabı > Güvenlik > 2 Adımlı Doğrulama açık olmalı,
// ardından "Uygulama Şifreleri" (App Passwords) bölümünden 16 haneli bir şifre
// oluşturup buraya yapıştırın (normal Gmail şifreniz DEĞİL).
// Adım adım: https://myaccount.google.com/apppasswords
// ─────────────────────────────────────────────────────────────

module.exports = {
  SITE_NAME: 'Kia Pet Kuaför & Spa',

  // Bildirimlerin ve randevu taleplerinin geleceği adres
  EMAIL_USER: 'barsel1107@gmail.com',

  // BURAYA Gmail "Uygulama Şifresi"ni (App Password) girin
  EMAIL_APP_PASSWORD: 'rrop vrjv ttny baoh',

  // Sunucunun dinleyeceği port
  PORT: 3001,

  // Bu sunucu canlıya alındığında (bir domain/VPS'e taşındığında) bu adresi
  // gerçek adresle değiştirin, örn: 'https://api.kiapetkuafor.com'
  // Onay/red e-postalarındaki linkler bu adres üzerinden oluşturulur.
  BASE_URL: 'http://localhost:3001'
};
